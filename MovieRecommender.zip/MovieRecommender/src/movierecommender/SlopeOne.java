package movierecommender;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;


/**
 *
 * @author sarah ortiz
 */
public class SlopeOne {

    static Map<Integer, Map<Integer, Double>> differences = new HashMap<>();
    static Map<Integer, Map<Integer, Integer>> frequencies = new HashMap<>();
    static Map<Integer, Map<Integer, Double>> outPreds = new HashMap<>();
    static Map<Integer, Map<Integer,Integer>> placeHolder = new HashMap<>();
    
    static Map<Integer, Double> inputUserRecommendations = new HashMap<>();
   public  SlopeOne(){
       System.out.println(UserRatings.inputUser);
    findRelations(UserRatings.smallerUserRatingsData);
   // placeHolder.put(1, UserRatings.inputRatings);
    predictRates(UserRatings.smallerUserRatingsData);
    inputUserReccomendations();
    
}
    /**
     * implementing the slope one algorithm first we need to find the
     * differences between the ratings of items and then the frequencies that
     * show how much they have been rated frequencies map = UserID, Movie ID, #
     * ratings differences map = UserID, MovieID, Difference between ratings
     * (movie 1 - movie 2)
     * @param userRatingsData
     */

    public static void findRelations(Map<Integer, Map<Integer, Integer>> userRatingsData) {

        int oldCount = 0;

        double oldDiff = 0.0;
        double obvDiff = 0.0;
        double oldVal = 0.0;
        int count = 0;
        for (Map<Integer, Integer> user : userRatingsData.values()) {
            for (Map.Entry<Integer, Integer> e : user.entrySet()) {
                if (!differences.containsKey(e.getKey())) {
                    differences.put(e.getKey(), new HashMap<Integer, Double>());
                    frequencies.put(e.getKey(), new HashMap<Integer, Integer>());
                }

                for (Map.Entry<Integer, Integer> ne : user.entrySet()) {
                    oldCount = 0;
                    if (frequencies.get(e.getKey()).containsKey(ne.getKey())) {
                        oldCount = frequencies.get(e.getKey()).get(ne.getKey());
                    }
                    oldDiff = 0.0;
                    if (differences.get(e.getKey()).containsKey(ne.getKey())) {
                        oldDiff = differences.get(e.getKey()).get(ne.getKey());
                    }
                    obvDiff = e.getValue() - ne.getValue();
                    frequencies.get(e.getKey()).put(ne.getKey(), oldCount + 1);
                    differences.get(e.getKey()).put(ne.getKey(), oldDiff + obvDiff);
                }
            }
        }
        for (Integer k : differences.keySet()) {
            for (Integer l : differences.get(k).keySet()) {
                oldVal = differences.get(k).get(l);
                count = frequencies.get(k).get(l);
                differences.get(k).put(l, oldVal / count);
            }

        }
    }

    /**
     * predicting the missing ratings of the users
     * @param userRatingsData
     * 
     */
    public static void predictRates(Map<Integer, Map<Integer,Integer>> userRatingsData) {
        HashMap<Integer, Double> userPredictions = new HashMap<Integer, Double>();
        HashMap<Integer,Integer>  userFreq = new HashMap<>();
        for(Integer j : differences.keySet()){
            userFreq.put(j, 0);
            userPredictions.put(j, 0.0);
        }
        for(Entry<Integer, Map<Integer,Integer>> e : userRatingsData.entrySet()){
            for(Integer id : e.getValue().keySet()){
                for (Integer nid : differences.keySet()) {
                    try{
                        double predVal = differences.get(nid).get(id) + e.getValue().get(id).doubleValue();
                        double finVal = predVal * frequencies.get(nid).get(id);
                        userPredictions.put(nid, userPredictions.get(nid)+ finVal);
                        userFreq.put(nid, userFreq.get(nid) + frequencies.get(nid).get(id));
                     //   System.out.println("here0");
                        
                    }catch (NullPointerException ex){
                    
                }
       
                }
            }
           

            outPreds.put(e.getKey(), userPredictions);
           // System.out.println("outPreds = " + outPreds.toString().replace("}","\n"));
        }
    }
    public static void  inputUserReccomendations(){
       // System.out.println("outPreds = " + outPreds);
       inputUserRecommendations = outPreds.get(UserRatings.inputUser);
     //System.out.println("inputUserRecommendations = " + inputUserRecommendations.toString().replace("[", "\n"));
    }
    
}
