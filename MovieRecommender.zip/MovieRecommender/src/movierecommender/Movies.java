package movierecommender;

import java.io.*;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

/**
 *
 * @author sarah ortiz
 */
public class Movies {

    static String[] values;
    static Map<Integer, String> movieMap;
    static Boolean DEBUG = false;

    public Movies() {
        movieMap = new HashMap<>();
        readMovieFile();

    }

    //return the number of Movies in the map
    public static int movieMapSize() {
        return movieMap.size();
    }

    //return the name of movie based off of ID
    public static String getMovieName(int id) {
        return movieMap.get(id);
    }

    //returns the map  of movies and their ids(keys)
    public Map<Integer, String> getMovieMap() {
        return movieMap;
    }

    //reading the file and entering the id and movie into the hashmap
    public static void readMovieFile() {
        String filename = "movies.txt";
        try {
            BufferedReader br = new BufferedReader(new FileReader(filename));
            String line = br.readLine();
            while (line != null) {
                values = line.split("\t");
                cleanUp(values);
                if (DEBUG) {
                    System.out.println(line);
//                   for (int i = 0; i < values[0].length(); i++) {
//                       //System.out.println((int)values[0].charAt(i));
//                   }
                    // System.out.println(">" + values[0]+"<" + values[0].length());
                }

                int movieID = Integer.parseInt(values[0]);
                String movieName = values[1];
                //System.out.println(movieID + " " + movieName);

                movieMap.put(movieID, movieName);
                line = br.readLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
//       File file = new File(filename); 
//       try {
//       Scanner sc = new Scanner(file);
//       while(sc.hasNext()){
//           String movie = sc.next();
//          String[] movies = movie.split(",");
//           System.out.println(movies[1]);
//       }
//       sc.close();
//       } catch (FileNotFoundException e){
//           e.printStackTrace();
//       }
    }

    public static Integer generateRandomMovie() {
        Random random = new Random();
        int randID = random.nextInt(movieMapSize());
        while (movieMap.get(randID) == null) {
            randID = random.nextInt(movieMapSize());
        }
        return randID;
    }

    public static void cleanUp(String[] messy) {

        for (int i = 0; i < messy.length; i++) {
            for (int j = 0; j < messy[i].length(); j++) {
                StringBuilder sb = new StringBuilder(messy[i]);
                int nums = (int) messy[i].charAt(j);
                if (nums == 65279) {
                    sb.deleteCharAt(j);
                    values[i] = sb.toString();
                }
            }
        }

    }

    public static void main(String[] args) {

        if (DEBUG) {
            System.out.println(movieMap);
            new Movies();
            readMovieFile();
            int test = generateRandomMovie();
            System.out.println("test = " + test);
            // System.out.println(movieMap.get(1));
            String mn = getMovieName(test);
            System.out.println(mn);
        }

    }
}
