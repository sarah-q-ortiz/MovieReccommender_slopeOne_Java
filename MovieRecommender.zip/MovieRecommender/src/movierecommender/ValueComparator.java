


package movierecommender;

import java.util.Comparator;
import java.util.Map;

/**
 *
 * @author sarah ortiz
 */
public class ValueComparator implements Comparator<Integer>{
private Map<Integer, Double> sort;
public ValueComparator(Map<Integer, Double> sort){
    this.sort=sort;
}
    @Override
    public int compare(Integer o1, Integer o2) {
        if(sort.get(01) >= sort.get(02)){
            return -1;
        }
            return 1;
        
    }

}
