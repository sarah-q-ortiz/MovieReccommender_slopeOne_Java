package movierecommender;

import java.io.*;
import java.util.*;
import java.util.Map.Entry;

/**
 *
 * @author sarah ortiz
 */
public class UserRatings {

    static String[] values;
    static Map<Integer, Map<Integer, Integer>> userRatingsData = new HashMap<>();
     static Map<Integer, Map<Integer, Integer>> smallerUserRatingsData = new HashMap<>();
     public static Map<Integer, Integer> inputRatings = new HashMap<>();
    Map<Integer, Integer> movieRating = new HashMap<>();
 
    static Boolean DEBUG = false;
    public static int size = 5;
 public static int inputUser= size ;
    public UserRatings() {
        readRatingFile();
      
    }

//filling maps mainly from GitHub
    public void readRatingFile() {
        String filename = "ratings.txt";
        int userID = 0;
        int movieID;
        int ratingval;
        try {
            BufferedReader br = new BufferedReader(new FileReader(filename));
            String line = br.readLine();
            while (line != null) {
                String[] values = line.split("\t");
                cleanUp(values);
                 userID = Integer.parseInt(values[0]);
                 movieID = Integer.parseInt(values[1]);
                 ratingval = (int) Double.parseDouble(values[2]);
                if (userRatingsData.containsKey(userID)) {
                    userRatingsData.get(userID).put(movieID, ratingval);
                   
                } else {
                    movieRating = new HashMap<>();
                    movieRating.put(movieID, ratingval);
                    userRatingsData.put(userID, movieRating);
                  
                }
                line = br.readLine();
            }
          
        } catch (IOException e) {
            e.printStackTrace();
        }
     lessRatings(userRatingsData);
    }
public static void lessRatings( Map<Integer, Map<Integer, Integer>> userRatingsData){
    for (int i = 1; i < size; i++) {
        smallerUserRatingsData.put(i, userRatingsData.get(i));
    }
    //System.out.println("smallerUserRatingsData = " + smallerUserRatingsData.toString().replace("}", "\n"));
}
    public static void addInputUser (){
        smallerUserRatingsData.put(inputUser, inputRatings);
    }
    public static void cleanUp(String[] messy) {
        for (int i = 0; i < messy.length; i++) {
            for (int j = 0; j < messy[i].length(); j++) {
                StringBuilder sb = new StringBuilder(messy[i]);
                int nums = (int) messy[i].charAt(j);
                if (nums == 65279) {
                    sb.deleteCharAt(j);
                    values[i] = sb.toString();
                }
            }
        }
    }

    public static void main(String[] args) {
        if (DEBUG) {
            new UserRatings();

        }
    }
}
